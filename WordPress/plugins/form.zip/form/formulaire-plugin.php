<?php
/*
Plugin Name: Mon Formulaire Plugin
Description: Un plugin pour insérer des formulaires via shortcode.
Version: 1.0
Author: NR Web Solution
*/

// Sécurité : Empêcher l'accès direct au fichier
if (!defined('ABSPATH')) {
    exit;
}